package com.hisilicion.histreaming;

public class GizThirdAccountType {
}
