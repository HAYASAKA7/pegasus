package com.hisilicion.histreaming;

public class GizDeviceSharing {
    public static void setListener(GizDeviceSharingListener listener) {

    }

}
