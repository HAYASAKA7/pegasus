package com.hisilicion.histreaming;

public class GizMessage {
}
